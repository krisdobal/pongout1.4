#ifndef _potmeter_H_
#define _potmeter_H_

void initPots();
uint16_t readPot0();
uint16_t readPot1();

#endif /* _potmeter_H_ */
