
#ifndef _inGame_H_
#define _inGame_H_

int startGame(uint8_t chosenLevel, uint8_t chosenSpeed);

#endif /* _inGame_H_ */

