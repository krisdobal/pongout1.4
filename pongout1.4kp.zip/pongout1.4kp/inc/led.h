#ifndef _led_H_
#define _led_H_

void initializeLed();
void setLed(uint8_t rgb);


#endif /* _led_H_ */

