#ifndef _joystick_H_
#define _joystick_H_

void initializeJoystick();
void initializeJoystickIRQ();
uint8_t readJoystick();


#endif /* _joystick_H_ */
