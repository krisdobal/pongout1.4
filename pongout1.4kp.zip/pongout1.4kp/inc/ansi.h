

#ifndef _ANSI_H_
#define _ANSI_H_
void gotoxy(int x, int y);
void hideCursor();
void bufferToAnsi();

#endif /* _ANSI_H_ */
