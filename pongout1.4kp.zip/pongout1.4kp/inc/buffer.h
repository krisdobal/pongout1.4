#ifndef _buffer_H_
#define _buffer_H_
volatile uint8_t buffer[512];

#endif /* _buffer_H_ */

